/* @ds-bundle: {"format":3,"namespace":"MetheaDesignSystem_7f822d","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Banner","sourcePath":"components/core/Banner.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"StatusChip","sourcePath":"components/core/StatusChip.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"RadioCard","sourcePath":"components/forms/RadioCard.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"ProgressDots","sourcePath":"components/research/ProgressDots.jsx"},{"name":"TheoryCard","sourcePath":"components/research/TheoryCard.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"4b6adb22d0a2","components/core/Banner.jsx":"a31ea9d3e5d1","components/core/Button.jsx":"bb366bfa3e68","components/core/Card.jsx":"454420954d9f","components/core/StatusChip.jsx":"b630b85982a8","components/core/Tag.jsx":"19f5077750df","components/forms/Input.jsx":"143a173f5fe1","components/forms/RadioCard.jsx":"8728ee0d54d3","components/forms/Select.jsx":"f25bc4f72631","components/research/ProgressDots.jsx":"12d7d9227e3d","components/research/TheoryCard.jsx":"3d8ec5a42f16","ui_kits/methea-app/BriefScreen.jsx":"207f68b5b6be","ui_kits/methea-app/FrameworkScreen.jsx":"a7e605c29336","ui_kits/methea-app/GateScreen.jsx":"924ea97865d0","ui_kits/methea-app/LoginScreen.jsx":"3bce7dbb32db","ui_kits/methea-app/TheoriesScreen.jsx":"4c64a6068853"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.MetheaDesignSystem_7f822d = window.MetheaDesignSystem_7f822d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
/**
 * Methea wordmark — Playfair Display at −4.5% tracking with the lime marker
 * swipe layered behind the letterforms. Never recolour the swipe.
 */
function Logo({
  size = 'sm',
  onDark = false,
  tagline = false
}) {
  const dims = {
    sm: {
      fontSize: '1.25rem',
      swipeH: 12,
      swipeBottom: 0
    },
    md: {
      fontSize: '2rem',
      swipeH: 19,
      swipeBottom: 0
    },
    lg: {
      fontSize: '2.75rem',
      swipeH: 26,
      swipeBottom: 1
    }
  }[size];
  const inkColor = onDark ? '#FBF9F3' : 'var(--ink)';
  // On dark backgrounds the swipe is muted so the ink ground shows through it
  // (a glaring full-opacity lime fights the light wordmark).
  const sw = onDark ? {
    a: 0.32,
    b: 0.16
  } : {
    a: 0.92,
    b: 0.5
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      flexDirection: 'column',
      gap: '0.5rem',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      display: 'inline-block',
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 500 58",
    width: "107%",
    height: dims.swipeH,
    preserveAspectRatio: "none",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      left: '-3.5%',
      bottom: dims.swipeBottom,
      zIndex: 1,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: "M8 44 Q4 40 10 36 L478 4 Q492 3 494 12 L498 30 Q499 40 486 42 L24 56 Q10 57 8 44 Z",
    fill: "#DDFF55",
    opacity: sw.a
  }), /*#__PURE__*/React.createElement("path", {
    d: "M30 40 L460 12 L462 24 L36 50 Z",
    fill: "#DDFF55",
    opacity: sw.b
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "'Playfair Display', Georgia, serif",
      fontSize: dims.fontSize,
      fontWeight: 400,
      letterSpacing: '-0.045em',
      color: inkColor,
      position: 'relative',
      zIndex: 2
    }
  }, "Methea")), tagline && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.625rem',
      letterSpacing: '0.2em',
      textTransform: 'uppercase',
      color: onDark ? '#8C8A82' : 'var(--graphite)'
    }
  }, "Your research, methodically"));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/core/Banner.jsx
try { (() => {
/**
 * AI confirmation banner — the co-constructive opener that starts every Socratic
 * gate from what the student already brought. Soft sheet card, body copy inside.
 */
function Banner({
  children,
  tone = 'neutral',
  style
}) {
  const tones = {
    neutral: {
      background: 'var(--sheet)',
      border: '1px solid var(--stone-soft)'
    },
    error: {
      background: 'var(--error-bg)',
      border: '1px solid var(--error)'
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '1rem 1.25rem',
      borderRadius: 'var(--radius)',
      ...tones[tone],
      ...style
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '0.9375rem',
      color: 'var(--graphite)',
      lineHeight: 1.6,
      margin: 0
    }
  }, children));
}
Object.assign(__ds_scope, { Banner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Banner.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Methea button. The ink-blue primary is the only filled action colour —
 * marker colours are never button fills. Sentence case, active voice.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  disabled = false,
  type = 'button',
  onClick,
  style,
  ...rest
}) {
  const pad = size === 'sm' ? '0.4rem 0.85rem' : '0.625rem 1.25rem';
  const fontSize = size === 'sm' ? '0.8125rem' : '0.9375rem';
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.4rem',
    padding: pad,
    borderRadius: 'var(--radius)',
    fontFamily: 'var(--font-ui)',
    fontSize,
    fontWeight: 600,
    lineHeight: 1.2,
    cursor: disabled ? 'default' : 'pointer',
    transition: 'opacity 0.1s, border-color 0.1s, background 0.1s',
    border: '1px solid transparent'
  };
  const variants = {
    primary: {
      background: disabled ? 'var(--paper-deep)' : 'var(--ink-blue)',
      color: disabled ? 'var(--pencil)' : 'var(--sheet)'
    },
    ghost: {
      background: 'transparent',
      color: disabled ? 'var(--pencil)' : 'var(--ink-blue)',
      borderColor: 'var(--stone)'
    },
    quiet: {
      background: 'transparent',
      color: disabled ? 'var(--pencil)' : 'var(--ink-blue)',
      padding: 0
    }
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    style: {
      ...base,
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => {
      if (!disabled && variant === 'primary') e.currentTarget.style.opacity = '0.9';
      if (!disabled && variant === 'ghost') e.currentTarget.style.borderColor = 'var(--ink-blue)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.opacity = '1';
      if (variant === 'ghost') e.currentTarget.style.borderColor = 'var(--stone)';
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
/**
 * Page card — the primary content container (sheet fill, soft stone border,
 * 14px radius). Optional uppercase eyebrow label.
 */
function Card({
  label,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--sheet)',
      border: '1px solid var(--stone-soft)',
      borderRadius: 'var(--radius-lg)',
      padding: '1.5rem',
      display: 'flex',
      flexDirection: 'column',
      gap: '0.75rem',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.6875rem',
      fontWeight: 700,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
      color: 'var(--pencil)'
    }
  }, label), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/StatusChip.jsx
try { (() => {
/**
 * Verification status chip — the single visual vocabulary for trust state.
 * Never invent a fourth state. Green = verified, gray = unverified, amber = outdated.
 */
function StatusChip({
  status = 'verified_doi',
  label,
  style
}) {
  const config = {
    verified_doi: {
      bg: 'var(--marker-green)',
      color: 'var(--verified-text)',
      icon: '✓',
      text: 'Verified · DOI found'
    },
    verified_classic: {
      bg: 'var(--marker-green)',
      color: 'var(--verified-text)',
      icon: '✓',
      text: 'Verified · Classic text'
    },
    unverified: {
      bg: 'var(--stone-soft)',
      color: 'var(--pencil)',
      icon: '?',
      text: 'Unverified — check manually'
    },
    outdated: {
      bg: 'var(--marker-yellow)',
      color: 'var(--warn-text)',
      icon: '⚠',
      text: 'Outdated — review changes'
    },
    reading: {
      bg: 'var(--sky)',
      color: 'var(--ink-blue)',
      icon: '+',
      text: 'In your reading list'
    }
  }[status];
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '0.3rem',
      padding: '2px 8px',
      borderRadius: 'var(--radius-sm)',
      fontSize: '0.75rem',
      fontWeight: 500,
      background: config.bg,
      color: config.color,
      ...style
    }
  }, config.icon, " ", label ?? config.text);
}
Object.assign(__ds_scope, { StatusChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/StatusChip.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
/**
 * Small meta tag — degree level, discipline, research type. Neutral by default;
 * the `sky` tone marks methodology/qualitative info.
 */
function Tag({
  children,
  tone = 'neutral',
  style
}) {
  const tones = {
    neutral: {
      background: 'var(--paper-deep)',
      color: 'var(--graphite)'
    },
    sky: {
      background: 'var(--sky)',
      color: 'var(--ink-blue)'
    }
  };
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      padding: '3px 10px',
      borderRadius: 'var(--radius-sm)',
      fontSize: '0.8125rem',
      fontWeight: 500,
      ...tones[tone],
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Text input / textarea. Sheet fill, stone border, ink-blue focus ring.
 * Pass `error` to switch to the error fill + border. Set `multiline` for textarea.
 */
function Input({
  multiline = false,
  error = false,
  label,
  hint,
  rows = 4,
  style,
  ...rest
}) {
  const fieldStyle = {
    width: '100%',
    padding: multiline ? '0.75rem 1rem' : '0.625rem 0.875rem',
    background: error ? 'var(--error-bg)' : 'var(--sheet)',
    border: `1px solid ${error ? 'var(--error)' : 'var(--stone)'}`,
    borderRadius: 'var(--radius)',
    fontFamily: 'var(--font-ui)',
    fontSize: '0.9375rem',
    color: 'var(--ink)',
    lineHeight: 1.6,
    outline: 'none',
    resize: multiline ? 'vertical' : undefined,
    ...style
  };
  const focus = e => {
    if (!error) {
      e.currentTarget.style.outline = '2px solid var(--ink-blue)';
      e.currentTarget.style.outlineOffset = '2px';
      e.currentTarget.style.borderColor = 'transparent';
    }
  };
  const blur = e => {
    e.currentTarget.style.outline = 'none';
    e.currentTarget.style.borderColor = error ? 'var(--error)' : 'var(--stone)';
  };
  const field = multiline ? /*#__PURE__*/React.createElement("textarea", _extends({
    rows: rows,
    style: fieldStyle,
    onFocus: focus,
    onBlur: blur
  }, rest)) : /*#__PURE__*/React.createElement("input", _extends({
    style: fieldStyle,
    onFocus: focus,
    onBlur: blur
  }, rest));
  if (!label && !hint) return field;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.375rem'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: '0.8125rem',
      fontWeight: 500,
      color: 'var(--graphite)'
    }
  }, label), field, hint && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: '0.8125rem',
      color: error ? 'var(--error)' : 'var(--pencil)',
      margin: 0,
      lineHeight: 1.4
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/RadioCard.jsx
try { (() => {
/**
 * Selectable option card — the radio control Methea uses for methodology and
 * gate choices. Title + description, ink-blue border + filled dot when selected.
 */
function RadioCard({
  title,
  description,
  selected = false,
  onSelect,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSelect,
    "aria-pressed": selected,
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: '0.75rem',
      width: '100%',
      padding: '1rem 1.25rem',
      background: 'var(--sheet)',
      border: `1px solid ${selected ? 'var(--ink-blue)' : 'var(--stone-soft)'}`,
      borderRadius: 'var(--radius)',
      cursor: 'pointer',
      textAlign: 'left',
      transition: 'border-color 0.1s',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flexShrink: 0,
      marginTop: '3px',
      width: '16px',
      height: '16px',
      borderRadius: '50%',
      border: `2px solid ${selected ? 'var(--ink-blue)' : 'var(--stone)'}`,
      background: selected ? 'var(--ink-blue)' : 'transparent',
      boxShadow: selected ? 'inset 0 0 0 3px var(--sheet)' : 'none'
    }
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontWeight: 600,
      fontSize: '0.9375rem',
      color: 'var(--ink)',
      marginBottom: '0.25rem'
    }
  }, title), description && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '0.875rem',
      color: 'var(--graphite)',
      lineHeight: 1.5
    }
  }, description)));
}
Object.assign(__ds_scope, { RadioCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/RadioCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Select dropdown matching the Methea field styling.
 * Pass `options` as [{ value, label }] or plain strings.
 */
function Select({
  options = [],
  placeholder = 'Select...',
  label,
  error = false,
  style,
  ...rest
}) {
  const fieldStyle = {
    width: '100%',
    padding: '0.625rem 0.875rem',
    background: error ? 'var(--error-bg)' : 'var(--sheet)',
    border: `1px solid ${error ? 'var(--error)' : 'var(--stone)'}`,
    borderRadius: 'var(--radius)',
    fontFamily: 'var(--font-ui)',
    fontSize: '0.9375rem',
    color: 'var(--ink)',
    outline: 'none',
    cursor: 'pointer',
    ...style
  };
  const norm = options.map(o => typeof o === 'string' ? {
    value: o,
    label: o
  } : o);
  const select = /*#__PURE__*/React.createElement("select", _extends({
    style: fieldStyle
  }, rest), /*#__PURE__*/React.createElement("option", {
    value: ""
  }, placeholder), norm.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)));
  if (!label) return select;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '0.375rem'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: '0.8125rem',
      fontWeight: 500,
      color: 'var(--graphite)'
    }
  }, label), select);
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/research/ProgressDots.jsx
try { (() => {
/**
 * Progress dots — linear step indicator for the wizard / Socratic gates.
 * Filled dots and lime "done" connectors up to the current step.
 */
function ProgressDots({
  total,
  current = 0,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '0.75rem'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, Array.from({
    length: total
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '12px',
      height: '12px',
      borderRadius: '50%',
      flexShrink: 0,
      border: `2px solid ${i <= current ? 'var(--ink-blue)' : 'var(--stone)'}`,
      background: i <= current ? 'var(--ink-blue)' : 'transparent'
    }
  }), i < total - 1 && /*#__PURE__*/React.createElement("div", {
    style: {
      width: '32px',
      height: '2px',
      background: i < current ? 'var(--marker-lime)' : 'var(--stone-soft)'
    }
  })))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '0.8125rem',
      color: 'var(--pencil)'
    }
  }, label));
}
Object.assign(__ds_scope, { ProgressDots });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/research/ProgressDots.jsx", error: String((e && e.message) || e) }); }

// components/research/TheoryCard.jsx
try { (() => {
/**
 * Theory card — the multi-select research-theory tile. Name + author, the
 * italic "why it fits" rationale (Source Serif), concept tags, and verification
 * chips. Ink-blue border + check badge when selected.
 */
function TheoryCard({
  name,
  author,
  year,
  whyItFits,
  concepts = [],
  status = 'verified_doi',
  inReadingList = false,
  selected = false,
  onSelect,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSelect,
    "aria-pressed": selected,
    style: {
      position: 'relative',
      display: 'block',
      width: '100%',
      textAlign: 'left',
      background: 'var(--sheet)',
      border: `1px solid ${selected ? 'var(--ink-blue)' : 'var(--stone-soft)'}`,
      borderRadius: 'var(--radius)',
      padding: '1rem',
      cursor: 'pointer',
      transition: 'border-color 0.1s',
      fontFamily: 'var(--font-ui)',
      ...style
    }
  }, selected && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: '12px',
      right: '12px',
      width: '20px',
      height: '20px',
      borderRadius: '50%',
      background: 'var(--ink-blue)',
      color: 'var(--sheet)',
      fontSize: '10px',
      fontWeight: 700,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontWeight: 600,
      fontSize: '0.9375rem',
      color: 'var(--ink)',
      paddingRight: '24px'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontSize: '0.6875rem',
      color: 'var(--pencil)',
      marginTop: '2px'
    }
  }, author, year ? `, ${year}` : ''), whyItFits && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'block',
      fontFamily: "'Source Serif 4', Georgia, serif",
      fontSize: '0.75rem',
      fontStyle: 'italic',
      color: 'var(--graphite)',
      lineHeight: 1.55,
      margin: '8px 0'
    }
  }, "\u201C", whyItFits, "\u201D"), concepts.length > 0 && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '0.375rem',
      flexWrap: 'wrap',
      marginBottom: '8px'
    }
  }, concepts.map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      padding: '1px 6px',
      background: 'var(--paper-deep)',
      color: 'var(--graphite)',
      borderRadius: 'var(--radius-sm)',
      fontSize: '0.625rem'
    }
  }, c))), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '4px',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusChip, {
    status: status
  }), inReadingList && /*#__PURE__*/React.createElement(__ds_scope.StatusChip, {
    status: "reading",
    label: "+ In your list"
  })));
}
Object.assign(__ds_scope, { TheoryCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/research/TheoryCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/methea-app/BriefScreen.jsx
try { (() => {
// Methea UI kit — Brief screen. The student's entry point: topic + degree +
// discipline, with optional reading-list and file disclosures.
const {
  Logo,
  Input,
  Select,
  Button
} = window.MetheaDesignSystem_7f822d;
const DEGREE_LEVELS = [{
  value: 'bachelor',
  label: "Bachelor's"
}, {
  value: 'masters',
  label: "Master's"
}, {
  value: 'phd',
  label: 'PhD'
}, {
  value: 'independent',
  label: 'Independent researcher'
}];
const DISCIPLINES = ['Business & Management', 'Economics', 'Education', 'Health Sciences', 'Information Systems', 'Psychology', 'Public Administration', 'Sociology', 'Other'];
function BriefScreen({
  onContinue
}) {
  const [topic, setTopic] = React.useState('');
  const [degree, setDegree] = React.useState('');
  const [discipline, setDiscipline] = React.useState('');
  const [showReading, setShowReading] = React.useState(false);
  const valid = topic.trim().length >= 10 && degree && discipline;
  return /*#__PURE__*/React.createElement("div", {
    style: bs.page
  }, /*#__PURE__*/React.createElement("div", {
    style: bs.col
  }, /*#__PURE__*/React.createElement(Logo, {
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: bs.heading
  }, "Tell me about your research"), /*#__PURE__*/React.createElement("p", {
    style: bs.sub
  }, "Start with your topic in plain words \u2014 I'll help you sharpen it from here.")), /*#__PURE__*/React.createElement("div", {
    style: bs.card
  }, /*#__PURE__*/React.createElement(Input, {
    multiline: true,
    rows: 4,
    value: topic,
    onChange: e => setTopic(e.target.value),
    placeholder: 'e.g. "How do solo founders in Central Asia decide when to raise outside funding?"'
  }), /*#__PURE__*/React.createElement("div", {
    style: bs.row
  }, /*#__PURE__*/React.createElement(Select, {
    label: "Degree level",
    options: DEGREE_LEVELS,
    value: degree,
    onChange: e => setDegree(e.target.value)
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Discipline",
    options: DISCIPLINES,
    value: discipline,
    onChange: e => setDiscipline(e.target.value)
  })), /*#__PURE__*/React.createElement("button", {
    style: bs.disclosure,
    onClick: () => setShowReading(v => !v)
  }, showReading ? '▾' : '▸', " Have a reading list already? ", /*#__PURE__*/React.createElement("span", {
    style: bs.optional
  }, "(optional)")), showReading && /*#__PURE__*/React.createElement(Input, {
    multiline: true,
    rows: 4,
    placeholder: "Paste your reading list \u2014 one entry per line or as a block of text."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      marginTop: '0.25rem'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    disabled: !valid,
    onClick: onContinue
  }, "Start my research \u2192")))));
}
const bs = {
  page: {
    minHeight: '100%',
    padding: '3rem 1rem',
    background: 'var(--paper)'
  },
  col: {
    width: '100%',
    maxWidth: '720px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '1.25rem'
  },
  heading: {
    fontSize: '1.875rem',
    marginBottom: '0.375rem'
  },
  sub: {
    fontSize: '0.9375rem',
    color: 'var(--graphite)'
  },
  card: {
    background: 'var(--sheet)',
    border: '1px solid var(--stone-soft)',
    borderRadius: 'var(--radius-lg)',
    padding: '2rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1.25rem'
  },
  row: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '1rem'
  },
  disclosure: {
    background: 'none',
    border: 'none',
    padding: 0,
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-ui)',
    color: 'var(--ink-blue)',
    cursor: 'pointer',
    textAlign: 'left'
  },
  optional: {
    color: 'var(--pencil)',
    fontWeight: 400
  }
};
window.BriefScreen = BriefScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/methea-app/BriefScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/methea-app/FrameworkScreen.jsx
try { (() => {
// Methea UI kit — Framework + dashboard. Static SVG framework diagram with a
// layout switcher, the Source-Serif narrative with verified citation chips,
// export actions, and the project summary the student lands on after first pass.
const {
  Logo,
  Card,
  Tag,
  StatusChip,
  Button
} = window.MetheaDesignSystem_7f822d;
const NODES = [{
  id: 'rbv',
  name: 'Resource-Based View',
  meta: 'Barney, 1991'
}, {
  id: 'eff',
  name: 'Effectuation',
  meta: 'Sarasvathy, 2001'
}, {
  id: 'out',
  name: 'Funding Decision',
  meta: 'outcome'
}];
const EDGES = [{
  from: 0,
  to: 2,
  label: 'enables'
}, {
  from: 1,
  to: 2,
  label: 'shapes timing'
}];
const LAYOUTS = {
  'hub-and-spoke': [{
    cx: 150,
    cy: 110
  }, {
    cx: 150,
    cy: 250
  }, {
    cx: 470,
    cy: 180
  }],
  hierarchy: [{
    cx: 180,
    cy: 80
  }, {
    cx: 180,
    cy: 280
  }, {
    cx: 500,
    cy: 180
  }],
  linear: [{
    cx: 110,
    cy: 180
  }, {
    cx: 320,
    cy: 180
  }, {
    cx: 540,
    cy: 180
  }]
};
const NODE_W = 168,
  NODE_H = 54;
function edgePoints(f, t) {
  const dx = t.cx - f.cx,
    dy = t.cy - f.cy;
  const len = Math.hypot(dx, dy) || 1;
  const ux = dx / len,
    uy = dy / len;
  const off = Math.abs(ux) * NODE_W / 2 + Math.abs(uy) * NODE_H / 2 + 8;
  return {
    x1: f.cx + ux * off,
    y1: f.cy + uy * off,
    x2: t.cx - ux * off,
    y2: t.cy - uy * off
  };
}
function Diagram({
  layout
}) {
  const pos = LAYOUTS[layout];
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 640 360",
    width: "100%",
    style: {
      display: 'block'
    },
    role: "img",
    "aria-label": "Research framework diagram"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("marker", {
    id: "arr",
    viewBox: "0 0 10 10",
    refX: "9",
    refY: "5",
    markerWidth: "8",
    markerHeight: "8",
    orient: "auto-start-reverse"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 0 0 L 10 5 L 0 10 z",
    fill: "#DDD8C6"
  }))), EDGES.map((e, i) => {
    const p = edgePoints(pos[e.from], pos[e.to]);
    return /*#__PURE__*/React.createElement("g", {
      key: i
    }, /*#__PURE__*/React.createElement("line", {
      x1: p.x1,
      y1: p.y1,
      x2: p.x2,
      y2: p.y2,
      stroke: "#DDD8C6",
      strokeWidth: "1.5",
      markerEnd: "url(#arr)"
    }), /*#__PURE__*/React.createElement("text", {
      x: (p.x1 + p.x2) / 2,
      y: (p.y1 + p.y2) / 2 - 6,
      textAnchor: "middle",
      fontFamily: "'Source Serif 4', Georgia, serif",
      fontStyle: "italic",
      fontSize: "11",
      fill: "#8C8A82"
    }, e.label));
  }), NODES.map((n, i) => {
    const p = pos[i];
    return /*#__PURE__*/React.createElement("g", {
      key: n.id
    }, /*#__PURE__*/React.createElement("rect", {
      x: p.cx - NODE_W / 2,
      y: p.cy - NODE_H / 2,
      width: NODE_W,
      height: NODE_H,
      rx: "8",
      fill: "#FBF9F3",
      stroke: "#11425D",
      strokeWidth: "1.5"
    }), /*#__PURE__*/React.createElement("text", {
      x: p.cx,
      y: p.cy - 6,
      textAnchor: "middle",
      fontFamily: "'Schibsted Grotesk', sans-serif",
      fontWeight: "600",
      fontSize: "13",
      fill: "#1C1C1C"
    }, n.name), /*#__PURE__*/React.createElement("text", {
      x: p.cx,
      y: p.cy + 13,
      textAnchor: "middle",
      fontFamily: "'Schibsted Grotesk', sans-serif",
      fontSize: "11",
      fill: "#8C8A82"
    }, n.meta));
  }));
}
function FrameworkScreen({
  onRestart
}) {
  const [layout, setLayout] = React.useState('hub-and-spoke');
  const labels = {
    'hub-and-spoke': 'Hub & spoke',
    hierarchy: 'Hierarchy',
    linear: 'Linear'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: fs.page
  }, /*#__PURE__*/React.createElement("div", {
    style: fs.col
  }, /*#__PURE__*/React.createElement(Logo, {
    size: "sm"
  }), /*#__PURE__*/React.createElement(Card, {
    label: "Your research question"
  }, /*#__PURE__*/React.createElement("span", {
    style: fs.question
  }, "How do solo founders in Central Asia decide when to raise outside funding?"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.5rem',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, null, "Master's"), /*#__PURE__*/React.createElement(Tag, null, "Business & Management"), /*#__PURE__*/React.createElement(Tag, {
    tone: "sky"
  }, "qualitative"))), /*#__PURE__*/React.createElement("div", {
    style: fs.diagramCard
  }, /*#__PURE__*/React.createElement("div", {
    style: fs.layoutRow
  }, /*#__PURE__*/React.createElement("span", {
    style: fs.layoutLabel
  }, "Layout"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.375rem'
    }
  }, Object.keys(labels).map(l => /*#__PURE__*/React.createElement("button", {
    key: l,
    onClick: () => setLayout(l),
    style: {
      ...fs.layoutBtn,
      ...(layout === l ? fs.layoutBtnActive : {})
    }
  }, labels[l])))), /*#__PURE__*/React.createElement("div", {
    style: fs.diagramWrap
  }, /*#__PURE__*/React.createElement(Diagram, {
    layout: layout
  }))), /*#__PURE__*/React.createElement("div", {
    style: fs.narrativeCard
  }, /*#__PURE__*/React.createElement("span", {
    style: fs.cardLabel
  }, "Framework narrative"), /*#__PURE__*/React.createElement("p", {
    style: fs.narrative
  }, "This framework positions the funding decision as an outcome shaped by two forces. The Resource-Based View explains why a founder's unique, hard-to-imitate resources", /*#__PURE__*/React.createElement("span", {
    style: fs.cite
  }, " (Barney, 1991)"), " enable stronger negotiating positions, while Effectuation accounts for how founders act under uncertainty using the means at hand", /*#__PURE__*/React.createElement("span", {
    style: fs.cite
  }, " (Sarasvathy, 2001)"), ", shaping when the moment to raise feels right."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '0.375rem',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(StatusChip, {
    status: "verified_doi",
    label: "\u2713 Barney, 1991"
  }), /*#__PURE__*/React.createElement(StatusChip, {
    status: "verified_doi",
    label: "\u2713 Sarasvathy, 2001"
  }))), /*#__PURE__*/React.createElement("div", {
    style: fs.actions
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "Export PNG"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost"
  }, "Export Word"), /*#__PURE__*/React.createElement(Button, {
    onClick: onRestart
  }, "Save framework \u2192")), /*#__PURE__*/React.createElement("div", {
    style: fs.nextCard
  }, /*#__PURE__*/React.createElement("span", {
    style: fs.cardLabel
  }, "Up next \u2014 Collect"), /*#__PURE__*/React.createElement("p", {
    style: fs.nextText
  }, "Generate an interview guide of 10\u201315 questions, each tagged to a concept in this framework."))));
}
const fs = {
  page: {
    minHeight: '100%',
    padding: '3rem 1rem',
    background: 'var(--paper)'
  },
  col: {
    width: '100%',
    maxWidth: '720px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '1.25rem'
  },
  question: {
    fontFamily: 'var(--font-display)',
    fontSize: '1.375rem',
    letterSpacing: '-0.015em',
    lineHeight: 1.35
  },
  diagramCard: {
    background: 'var(--sheet)',
    border: '1px solid var(--stone-soft)',
    borderRadius: 'var(--radius-lg)',
    padding: '1rem 1.25rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  layoutRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '0.75rem'
  },
  layoutLabel: {
    fontSize: '0.6875rem',
    fontWeight: 700,
    color: 'var(--pencil)',
    textTransform: 'uppercase',
    letterSpacing: '0.08em'
  },
  layoutBtn: {
    padding: '4px 12px',
    border: '1px solid var(--stone)',
    borderRadius: 'var(--radius-sm)',
    background: 'var(--sheet)',
    color: 'var(--graphite)',
    fontSize: '0.8125rem',
    fontFamily: 'var(--font-ui)',
    cursor: 'pointer'
  },
  layoutBtnActive: {
    background: 'var(--ink-blue)',
    color: 'var(--sheet)',
    borderColor: 'var(--ink-blue)'
  },
  diagramWrap: {
    background: 'var(--paper)',
    border: '1px solid var(--stone-soft)',
    borderRadius: 'var(--radius)',
    padding: '0.5rem'
  },
  narrativeCard: {
    background: 'var(--sheet)',
    border: '1px solid var(--stone-soft)',
    borderRadius: 'var(--radius)',
    padding: '1.25rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.75rem'
  },
  cardLabel: {
    fontSize: '0.6875rem',
    fontWeight: 700,
    color: 'var(--pencil)',
    textTransform: 'uppercase',
    letterSpacing: '0.08em'
  },
  narrative: {
    fontFamily: 'var(--font-reading)',
    fontSize: '0.9375rem',
    lineHeight: 1.7,
    color: 'var(--graphite)'
  },
  cite: {
    color: 'var(--ink-blue)',
    fontStyle: 'normal'
  },
  actions: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '0.75rem'
  },
  nextCard: {
    padding: '1rem 1.25rem',
    background: 'var(--paper-deep)',
    border: '1px dashed var(--stone)',
    borderRadius: 'var(--radius)',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.25rem'
  },
  nextText: {
    fontSize: '0.9375rem',
    color: 'var(--graphite)'
  }
};
window.FrameworkScreen = FrameworkScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/methea-app/FrameworkScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/methea-app/GateScreen.jsx
try { (() => {
// Methea UI kit — Socratic Gate 1. Co-constructive question wizard that starts
// from what the student already brought; one choice per step.
const {
  Logo,
  Banner,
  RadioCard,
  ProgressDots,
  Button
} = window.MetheaDesignSystem_7f822d;
const QUESTIONS = [{
  id: 'scope',
  prompt: 'Your question touches a few things at once. Which is closest to what you most want to understand?',
  options: [{
    value: 'timing',
    title: 'The timing of the decision',
    description: 'When and why founders judge the moment is right to raise.'
  }, {
    value: 'criteria',
    title: 'The criteria they weigh',
    description: 'What signals and trade-offs shape the choice to raise or not.'
  }, {
    value: 'context',
    title: 'The regional context',
    description: 'How the Central Asian ecosystem shapes funding decisions.'
  }]
}, {
  id: 'lens',
  prompt: 'And whose perspective sits at the centre of your study?',
  options: [{
    value: 'founders',
    title: 'The founders themselves',
    description: 'Lived experience and decision logic of the people raising.'
  }, {
    value: 'investors',
    title: 'The investors',
    description: 'How funders read and respond to early-stage founders.'
  }]
}];
function GateScreen({
  onContinue
}) {
  const [step, setStep] = React.useState(0);
  const [answers, setAnswers] = React.useState({});
  const current = QUESTIONS[step];
  const selected = answers[current.id];
  const isLast = step === QUESTIONS.length - 1;
  function forward() {
    if (!selected) return;
    if (isLast) {
      onContinue();
      return;
    }
    setStep(s => s + 1);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: gs.page
  }, /*#__PURE__*/React.createElement("div", {
    style: gs.col
  }, /*#__PURE__*/React.createElement(Logo, {
    size: "sm"
  }), /*#__PURE__*/React.createElement(Banner, null, "Based on your brief, your question seems to be about ", /*#__PURE__*/React.createElement("strong", null, "when Central Asian founders decide to raise outside funding"), ". Let's sharpen it together."), /*#__PURE__*/React.createElement(ProgressDots, {
    total: QUESTIONS.length,
    current: step,
    label: `Question ${step + 1} of ${QUESTIONS.length}`
  }), /*#__PURE__*/React.createElement("h3", {
    style: gs.question
  }, current.prompt), /*#__PURE__*/React.createElement("div", {
    style: gs.options
  }, current.options.map(opt => /*#__PURE__*/React.createElement(RadioCard, {
    key: opt.value,
    title: opt.title,
    description: opt.description,
    selected: selected === opt.value,
    onSelect: () => setAnswers(a => ({
      ...a,
      [current.id]: opt.value
    }))
  }))), /*#__PURE__*/React.createElement("div", {
    style: gs.nav
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    onClick: () => step === 0 ? null : setStep(s => s - 1)
  }, "\u2190 Back"), /*#__PURE__*/React.createElement(Button, {
    disabled: !selected,
    onClick: forward
  }, isLast ? 'Finish →' : 'Continue →'))));
}
const gs = {
  page: {
    minHeight: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '3rem 1rem',
    background: 'var(--paper)'
  },
  col: {
    width: '100%',
    maxWidth: '720px',
    display: 'flex',
    flexDirection: 'column',
    gap: '1.5rem'
  },
  question: {
    fontSize: '1.125rem',
    fontWeight: 600,
    color: 'var(--ink)',
    lineHeight: 1.4
  },
  options: {
    display: 'flex',
    flexDirection: 'column',
    gap: '0.625rem'
  },
  nav: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  }
};
window.GateScreen = GateScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/methea-app/GateScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/methea-app/LoginScreen.jsx
try { (() => {
// Methea UI kit — Login screen. Magic link + Google OAuth, recreated cosmetically.
const {
  Logo
} = window.MetheaDesignSystem_7f822d;
function GoogleIcon() {
  return /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 18 18",
    style: {
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M17.64 9.2c0-.637-.057-1.251-.164-1.84H9v3.481h4.844c-.209 1.125-.843 2.078-1.796 2.717v2.258h2.908c1.702-1.567 2.684-3.874 2.684-6.615z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#34A853",
    d: "M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 0 0 9 18z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#FBBC05",
    d: "M3.964 10.71A5.41 5.41 0 0 1 3.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 0 0 0 9c0 1.452.348 2.827.957 4.042l3.007-2.332z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 0 0 .957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z"
  }));
}
function LoginScreen({
  onContinue
}) {
  const [email, setEmail] = React.useState('');
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: ls.page
  }, /*#__PURE__*/React.createElement("div", {
    style: ls.col
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: '0.5rem'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    size: "lg",
    tagline: true
  })), /*#__PURE__*/React.createElement("h1", {
    style: ls.heading
  }, "Sign in to continue"), /*#__PURE__*/React.createElement("p", {
    style: ls.sub
  }, "No password \u2014 we'll email you a one-time link."), sent ? /*#__PURE__*/React.createElement("div", {
    style: ls.card
  }, /*#__PURE__*/React.createElement("p", {
    style: ls.sentTitle
  }, "Check your inbox"), /*#__PURE__*/React.createElement("p", {
    style: ls.sentBody
  }, "We sent a sign-in link to ", /*#__PURE__*/React.createElement("strong", null, email || 'you@university.edu'), ".", /*#__PURE__*/React.createElement("br", null), "Click it to continue \u2014 no password needed."), /*#__PURE__*/React.createElement("button", {
    style: ls.continueLink,
    onClick: onContinue
  }, "Simulate the link click \u2192")) : /*#__PURE__*/React.createElement("div", {
    style: ls.card
  }, /*#__PURE__*/React.createElement("button", {
    style: ls.googleBtn,
    onClick: onContinue
  }, /*#__PURE__*/React.createElement(GoogleIcon, null), " Continue with Google"), /*#__PURE__*/React.createElement("div", {
    style: ls.divider
  }, /*#__PURE__*/React.createElement("span", {
    style: ls.dividerText
  }, "or")), /*#__PURE__*/React.createElement("label", {
    style: ls.label,
    htmlFor: "email"
  }, "Email"), /*#__PURE__*/React.createElement("input", {
    id: "email",
    type: "email",
    placeholder: "you@university.edu",
    value: email,
    onChange: e => setEmail(e.target.value),
    style: ls.input
  }), /*#__PURE__*/React.createElement("button", {
    style: ls.submitBtn,
    onClick: () => setSent(true)
  }, "Send sign-in link"))));
}
const ls = {
  page: {
    minHeight: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '3rem 1rem',
    background: 'var(--paper)'
  },
  col: {
    width: '100%',
    maxWidth: '400px',
    display: 'flex',
    flexDirection: 'column',
    gap: '0.5rem'
  },
  heading: {
    fontSize: '1.75rem',
    textAlign: 'center',
    marginTop: '1rem'
  },
  sub: {
    fontSize: '0.9375rem',
    color: 'var(--pencil)',
    textAlign: 'center',
    marginBottom: '1rem'
  },
  card: {
    background: 'var(--sheet)',
    border: '1px solid var(--stone-soft)',
    borderRadius: 'var(--radius-lg)',
    padding: '2rem',
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem'
  },
  googleBtn: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.625rem',
    width: '100%',
    padding: '0.625rem 1rem',
    background: '#fff',
    border: '1px solid #dadce0',
    borderRadius: 'var(--radius)',
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-ui)',
    cursor: 'pointer',
    color: 'var(--ink)'
  },
  divider: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'var(--pencil)',
    fontSize: '0.8125rem',
    borderTop: '1px solid var(--stone-soft)',
    position: 'relative',
    height: '1px',
    margin: '0.25rem 0'
  },
  dividerText: {
    background: 'var(--sheet)',
    padding: '0 0.75rem',
    position: 'absolute',
    top: '-0.6rem'
  },
  label: {
    fontSize: '0.875rem',
    fontWeight: 500,
    color: 'var(--graphite)'
  },
  input: {
    width: '100%',
    padding: '0.625rem 0.875rem',
    border: '1px solid var(--stone)',
    borderRadius: 'var(--radius)',
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-ui)',
    background: 'var(--sheet)',
    color: 'var(--ink)',
    outline: 'none'
  },
  submitBtn: {
    width: '100%',
    padding: '0.625rem 1rem',
    background: 'var(--ink-blue)',
    color: 'var(--sheet)',
    border: 'none',
    borderRadius: 'var(--radius)',
    fontSize: '0.9375rem',
    fontFamily: 'var(--font-ui)',
    fontWeight: 600,
    cursor: 'pointer'
  },
  sentTitle: {
    fontFamily: 'var(--font-display)',
    fontSize: '1.25rem',
    color: 'var(--ink)'
  },
  sentBody: {
    fontSize: '0.9375rem',
    color: 'var(--graphite)',
    lineHeight: 1.6
  },
  continueLink: {
    background: 'none',
    border: 'none',
    padding: 0,
    color: 'var(--ink-blue)',
    fontFamily: 'var(--font-ui)',
    fontSize: '0.9375rem',
    fontWeight: 600,
    cursor: 'pointer',
    textAlign: 'left',
    marginTop: '0.5rem'
  }
};
window.LoginScreen = LoginScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/methea-app/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/methea-app/TheoriesScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Methea UI kit — Theory discovery. Suggested-first theory cards, multi-select
// (pick 2–4), each shipping its "why it fits" and verification chip.
const {
  Logo,
  TheoryCard,
  Button
} = window.MetheaDesignSystem_7f822d;
const THEORIES = [{
  id: 'rbv',
  name: 'Resource-Based View',
  author: 'Barney',
  year: 1991,
  status: 'verified_doi',
  inReadingList: true,
  whyItFits: 'Maps the unique resources a founder controls to competitive advantage — central to why some raise on better terms.',
  concepts: ['VRIN', 'capabilities']
}, {
  id: 'sct',
  name: 'Social Cognitive Theory',
  author: 'Bandura',
  year: 1986,
  status: 'verified_classic',
  inReadingList: false,
  whyItFits: 'Explains how founders learn timing cues from peers and mentors in your regional ecosystem.',
  concepts: ['self-efficacy']
}, {
  id: 'eff',
  name: 'Effectuation',
  author: 'Sarasvathy',
  year: 2001,
  status: 'verified_doi',
  inReadingList: true,
  whyItFits: 'Models how founders act under uncertainty using means at hand — directly about the raise-or-wait judgment.',
  concepts: ['means-driven', 'affordable loss']
}, {
  id: 'inst',
  name: 'Institutional Theory',
  author: 'DiMaggio & Powell',
  year: 1983,
  status: 'unverified',
  inReadingList: false,
  whyItFits: 'Frames how regional norms and funder expectations pressure founders toward certain funding paths.',
  concepts: ['isomorphism', 'legitimacy']
}];
function TheoriesScreen({
  onContinue
}) {
  const [picked, setPicked] = React.useState({
    rbv: true,
    eff: true
  });
  const count = Object.values(picked).filter(Boolean).length;
  const toggle = id => setPicked(p => ({
    ...p,
    [id]: !p[id]
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: ts.page
  }, /*#__PURE__*/React.createElement("div", {
    style: ts.col
  }, /*#__PURE__*/React.createElement(Logo, {
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: ts.heading
  }, "Theories that tend to fit"), /*#__PURE__*/React.createElement("p", {
    style: ts.sub
  }, "Based on your question about founder funding timing, these tend to fit well. Pick 2\u20134 to see how they relate.")), /*#__PURE__*/React.createElement("div", {
    style: ts.grid
  }, THEORIES.map(t => /*#__PURE__*/React.createElement(TheoryCard, _extends({
    key: t.id
  }, t, {
    selected: !!picked[t.id],
    onSelect: () => toggle(t.id)
  })))), /*#__PURE__*/React.createElement("div", {
    style: ts.footer
  }, /*#__PURE__*/React.createElement("span", {
    style: ts.count
  }, count, " selected", count < 2 ? ' — pick at least 2' : ''), /*#__PURE__*/React.createElement(Button, {
    disabled: count < 2,
    onClick: onContinue
  }, "Build my framework \u2192"))));
}
const ts = {
  page: {
    minHeight: '100%',
    padding: '3rem 1rem',
    background: 'var(--paper)'
  },
  col: {
    width: '100%',
    maxWidth: '720px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column',
    gap: '1.25rem'
  },
  heading: {
    fontSize: '1.875rem',
    marginBottom: '0.375rem'
  },
  sub: {
    fontSize: '0.9375rem',
    color: 'var(--graphite)',
    maxWidth: '560px'
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '0.625rem'
  },
  footer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: '0.5rem'
  },
  count: {
    fontSize: '0.8125rem',
    color: 'var(--pencil)'
  }
};
window.TheoriesScreen = TheoriesScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/methea-app/TheoriesScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Banner = __ds_scope.Banner;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.StatusChip = __ds_scope.StatusChip;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.RadioCard = __ds_scope.RadioCard;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.ProgressDots = __ds_scope.ProgressDots;

__ds_ns.TheoryCard = __ds_scope.TheoryCard;

})();
