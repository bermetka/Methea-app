# Methea Design System

> "Your research, methodically." · METHod + THEa (Greek goddess of sight)
> Ink on paper, marker in hand.

The single source of truth for designing Methea — colours, type, fonts, voice,
reusable components, and a full UI-kit recreation of the product.

---

## 1 · What Methea is

Methea guides Master's and PhD students from an assignment brief to structured
research findings. It is a **process tool, not an output tool** — it scaffolds
the student's thinking (research question → theory → framework → methodology →
analysis) but **never writes the discussion, conclusion, or final report**. That
line is the whole positioning: it is what makes Methea a tool universities
recommend instead of ban.

Three-layer architecture: **Plan** (question refinement, theory discovery,
framework builder, methodology) → **Collect** (interview guides, transcription)
→ **Analyse** (AI coding against the framework, theme synthesis, structured
findings). Threaded through it are **three Socratic gates** — structured
dialogues at fixed points where the AI co-constructs (never interrogates),
always starting from what the student already brought.

A closed, curated theory library plus OpenAlex/CrossRef citation verification
are the #1 trust mitigation: every citation is verified before it is shown, and
the AI never invents author names or DOIs.

Related product: **o-nion** (async voice customer research for founders) shares
the same infrastructure but is out of scope for this system.

### Sources this system was built from
- **Codebase:** `methea-app/` — Next.js 14 App Router. Key files read:
  `app/globals.css`, `app/layout.tsx`, `app/login/LoginForm.tsx`,
  `app/onboarding/page.tsx`, `app/project/[id]/{brief,gate1,theories,framework}`,
  `components/ui/{Logo,StatusChip,RadioCard,FrameworkDiagram}.tsx`,
  and `CLAUDE.md` (product context).
- **Brandbook:** `methea-app/docs/methea-brandbook-v2.html` — the canonical brand spec.
- No Figma was provided.

---

## 2 · Content fundamentals (voice & copy)

Tone: **co-constructive · precise, not cold · reasoned, always · calm under
deadline** (the user is anxious at 2am).

- **Person.** Write from the student's side of the screen. The AI speaks as a
  collaborator ("Let's sharpen it together"), not an examiner. Use "you/your"
  for the student; "I/I'll" sparingly for the assistant ("I'll help you sharpen it").
- **Casing.** Sentence case **everywhere** — buttons, labels, headings. Never ALL-CAPS in buttons. (The only uppercase is the 11px micro-label eyebrow with +8% tracking.)
- **Verbs.** Active and plain. "Start my research →", "Save and continue →", "Pick 2–4 theories" — never "Submit", which reads as form bureaucracy.
- **Errors are guidance.** Begin with the action, never "Error:". → *"Add a bit more — a research topic needs at least a sentence to work with."*
- **AI ships with its "why".** Every suggestion carries a plain-language reason tied to *this specific* question. Generic praise is not a why. *"Resource-Based View fits your question about competitive advantage — it explains why firms with unique resources outperform."*
- **Suggestion, not prescription.** "These **tend to** fit well" / "your question **seems to be** about…". Start every gate from what the student brought: *"Based on your [thing], [acknowledgement]. Let's [do x] together."*
- **CTA pattern.** Progression buttons take a trailing arrow ("Continue →", "Build my framework →", "Finish →").
- **No emoji** in product copy. Status is carried by the three verification glyphs (✓ ? ⚠), not decorative emoji. (A 📄 file glyph appears only in the upload dropzone.)
- **The line, in copy too.** Never write microcopy that promises to write, interpret, or "humanize" the student's prose.

---

## 3 · Visual foundations

**The vibe.** Analogue stationery — warm paper, dark ink, a single hand-drawn
lime marker swipe. Matte, calm, editorial. Not a SaaS dashboard; a clean desk
with one good pen.

- **Colour ratio is LOCKED: ~70% paper · ~25% ink · ~5% marker.**
  - *Paper* (`#F6F2E8` app, `#FBF9F3` sheet/cards, `#EDE7D8` wells) — backgrounds only.
  - *Ink* (`#1C1C1C` text/logo, `#4A4A47` body, `#8C8A82` muted, `#11425D` ink-blue) — text and the **one** interactive colour. Ink-blue is the only filled-action colour.
  - *Marker* (`#FFE66D` yellow, `#DDFF55` lime, `#B7F171` green) — highlights and small chips **only**. Never a button fill, never a large area, never a background.
- **Type.** Three faces, one job each:
  - **Playfair Display** (serif) — wordmark, h1, h2. Signature **negative tracking**: −4.5% wordmark, −2.5% display, −1.5% headings. Weight 400 for elegance.
  - **Schibsted Grotesk** (sans) — the default: all UI, body, labels, buttons, captions.
  - **Source Serif 4** (italic serif) — long-form reading only: AI rationale and "why it fits".
  - Caveat is available for rare handwritten margin notes; use sparingly.
- **Spacing.** 4px base; every gap is a multiple of 4 (`--space-1…16`). Working width is a single **720px** column, centred, 3rem top padding, 13" laptop first. No sidebars in the product (mobile is status-viewing only).
- **Corners.** `--radius-sm` 6px (chips), `--radius` 10px (buttons, inputs), `--radius-lg` 14px (cards).
- **Cards.** Sheet fill, 1px soft-stone border (`#E9E4D6`), 14px radius. Borders do the separating — **shadows are barely there** (`0 1px 3px rgba(28,28,28,.05)`); paper is matte. Reserve `--shadow-pop` for dialogs/menus only.
- **Borders over fills.** Selected states = ink-blue 1px border (+ a filled radio dot or a small ✓ badge), not a coloured fill.
- **Backgrounds.** Flat paper. **No gradients, no photographic hero imagery, no textures.** The only "illustration" in the entire brand is the marker swipe.
- **The swipe.** A separate SVG layer of lime `#DDFF55` at ~90% opacity sitting behind the wordmark (multiply feel — ink reads through). Diagonal, through the lower half of the word. On the landing page it draws on over ~400ms. Clear space = the height of the "M". Never recolour, rotate, or use it without the word (except the favicon "M").
- **Motion.** Restrained and quick. `--dur-fast` 0.1s for hover/border-colour, `--dur` 0.2s for section fades, `--dur-swipe` 0.4s for the logo draw-on. Spinners use a lime top-border on a stone ring. No bounces, no parallax, no decorative loops.
- **Hover / press.** Primary button → `opacity: 0.9`. Ghost button → border brightens to ink-blue. No scale/shrink on press. Links underline on hover.
- **Imagery colour.** There is essentially none; if any is added it should stay warm and matte to sit on paper — never cool, glossy, or high-contrast.
- **Transparency/blur.** Effectively unused. Keep surfaces opaque; this is paper, not glass.

---

## 4 · Iconography

Methea has **no icon library and no icon font.** Its visual language is
deliberately typographic:

- **Verification glyphs** carry all status — a locked vocabulary: `✓` verified,
  `?` unverified, `⚠` outdated, `+` "in your reading list". Always rendered
  inside a `StatusChip`, never loose.
- **Unicode arrows & carets** are the only "icons" in flow: `→` on forward CTAs,
  `←` on back, `▸ / ▾` for disclosure toggles, `📄` only inside the file dropzone.
- **Brand SVGs** are hand-authored and few: the marker **swipe**, the wordmark
  lockup, and the favicon "M". These live in `assets/` (`methea-swipe.svg`,
  `methea-logo.svg`, `methea-mark.svg`, plus `favicon.ico`). The Google "G"
  multicolour mark appears only on the OAuth button (recreated inline in the
  login screen).
- **The framework diagram** is built from plain SVG rects + arrowhead markers —
  not an icon set.

**If a UI genuinely needs line icons** (none exist in the product today), use
**Lucide** from CDN — thin, single-weight strokes that match the restrained,
editorial feel — and flag it as an addition, since it is not part of the
shipped brand. Never hand-roll decorative SVG icons or substitute emoji.

---

## 5 · Index / manifest

**Root**
- `styles.css` — the single entry point consumers link. `@import`-only.
- `readme.md` — this guide.
- `SKILL.md` — Agent-Skills front-matter for downloading into Claude Code.

**`tokens/`** (all reached from `styles.css`)
- `fonts.css` — Google Fonts `@import` for Playfair Display, Schibsted Grotesk, Source Serif 4, Caveat.
- `colors.css` — base palette + semantic aliases.
- `typography.css` — families, tracking, scale, weights, line-heights.
- `spacing.css` — 4px scale, radii, borders, layout, shadows, motion.
- `base.css` — element resets, headings, `.label`, `.reading`, keyframes.

**`assets/`** — `methea-swipe.svg`, `methea-logo.svg`, `methea-mark.svg`, `favicon.ico`.

**`guidelines/`** — 12 foundation specimen cards (Colors, Type, Spacing, Brand) shown in the Design System tab.

**`components/`** — reusable primitives (namespace `window.MetheaDesignSystem_7f822d`):
- `brand/` — **Logo**
- `core/` — **Button**, **Tag**, **StatusChip**, **Card**, **Banner**
- `forms/` — **Input**, **Select**, **RadioCard**
- `research/` — **TheoryCard**, **ProgressDots**

**`ui_kits/methea-app/`** — full click-through research wizard:
`index.html` + `LoginScreen`, `BriefScreen`, `GateScreen`, `TheoriesScreen`, `FrameworkScreen`.

---

## 6 · The line we never cross
Methea scaffolds thinking. It never writes the student's discussion, conclusion,
or report; it never interprets what findings *mean*; it never generates
submittable prose. Every theory and citation comes from the closed library or is
OpenAlex-verified. Design nothing that implies otherwise.
